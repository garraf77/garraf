export default async function handler(req, res) {
  const { tier = "RARE", set = "Metallic Gold LE", discount = "10" } = req.query;

  const query = `
    query MarketplaceListings($input: ListingsInput, $sort: ListingsSort) {
      listings(input: $input, sort: $sort) {
        id
        priceUsd
        fairMarketValueUsd
        discountPercent
        nft {
          name serialNumber permalink setName tier
        }
      }
    }
  `;

  const variables = {
    input: {
      collectionSlugs: ["nba-top-shot"],
      tiers: [tier],
      setNames: [set],
      discountPercentGte: parseInt(discount, 10)
    },
    sort: { field: "DISCOUNT", direction: "DESC" }
  };

  try {
    const resp = await fetch("https://www.flowty.io/graphql", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, variables })
    });
    const json = await resp.json();
    res.setHeader("Cache-Control", "s-maxage=30, stale-while-revalidate");
    return res.status(200).json(json.data.listings);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
